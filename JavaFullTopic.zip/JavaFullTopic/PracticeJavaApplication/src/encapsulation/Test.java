
package encapsulation;


public class Test {
    public static void main(String[] args) {
       
        Person p1=new Person();
        p1.setName("tamanna");
        System.out.println("my name is "+p1.getName());
        
        
    }
    
}

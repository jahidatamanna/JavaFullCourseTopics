
package thisKeyword;


public class Test {
    public static void main(String[] args) {
        
        
        Person p1=new Person("tamanna",24);
        p1.display();
        
         Person p2=new Person("jahida",25,"black");
        p2.display();
        
        
        
    }
    
}

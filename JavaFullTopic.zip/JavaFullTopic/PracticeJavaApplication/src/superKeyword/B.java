
package superKeyword;


public class B  extends A{
    
    int x=5; // variable
    
    B(){
        super();
        System.out.println("B's constructor"); // constructor
    }
    
    @Override
    void display(){ // method
    super.display();
       // System.out.println(x);
        System.out.println(super.x);
        System.out.println(x);
        
        
        
    }

    
    
}

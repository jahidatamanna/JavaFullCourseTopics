
package superKeyword;


public class A {
    int x=10;
    
    A(){
        System.out.println("A's constructor");
    
    }
    
    void display(){
    
        System.out.println("Super Keyword A");
    }
    
}

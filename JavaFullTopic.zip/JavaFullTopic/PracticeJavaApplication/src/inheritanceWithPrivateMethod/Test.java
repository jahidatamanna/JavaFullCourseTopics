
package inheritanceWithPrivateMethod;


public class Test {
    public static void main(String[] args) {
     
   Teacher t1=new Teacher();
  
   t1.setName(" Tamanna");
   t1.setAge(24);
  t1.setQualification(" BSC in CSE");
   t1.display2();
        
        
        
    }
    
    
  
           
           
   
    
    
}

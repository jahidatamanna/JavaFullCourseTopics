
package inheritanceWithPrivateMethod;


public class Person {
    
    private String Name;
    private int age;
    


    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    void display1(){
    
        System.out.println("Name : "+Name);
        System.out.println("age : "+age);
    
    }
    
    
}

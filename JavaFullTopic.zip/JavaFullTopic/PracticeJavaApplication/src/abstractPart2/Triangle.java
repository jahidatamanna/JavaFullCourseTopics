
package abstractPart2;


public  class Triangle extends Shape {
    //diml1 ,diml2
    
    Triangle(double diml1,double diml2){ //non abstract class
       super(diml1,diml2);
    }
    
    void area(){
    
    double result=diml1*diml2;
        System.out.println("The area of Triangle is : " +result);
    }
    
    
}


package abstractPart2;


public class Rectangle extends Shape {
    
    Rectangle(double diml1,double diml2){
    
        super(diml1,diml2);
        
   
    }
    
    void area(){
    
    double result=diml1*diml2;
        System.out.println("The area of Rectangle is : " +result);
    
    }
    
}

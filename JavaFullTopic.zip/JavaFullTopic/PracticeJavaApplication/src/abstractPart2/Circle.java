
package abstractPart2;

public class Circle extends Shape {
    
    Circle(double diml1,double diml2){
    super(diml1,diml2);
    
    }
    
    void area(){
    
      double  result=3.1416*diml1*diml2;
        System.out.println("The area of circle is : " +result);
    
    
    }
    
}

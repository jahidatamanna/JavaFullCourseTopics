
package abstractPart2;


public abstract class Shape {
    
    double diml1,diml2;
    
    Shape(double diml1,double diml2){ //non abstract class
        this.diml1=diml1;
        this.diml2=diml2;
    }
    
    abstract void area();
    
}


package boxProblem;


public class BoxVolume {
    public static void main(String[] args) {
        
        Box box1=new Box(10,10,10);
        Box box2=new Box(20,30,10);
        
        box1.displayVolt();
        box2.displayVolt();
        
        
    }
    
}

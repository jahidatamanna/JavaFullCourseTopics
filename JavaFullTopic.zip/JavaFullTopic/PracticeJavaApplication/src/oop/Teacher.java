
package oop;

public class Teacher {
    
    String name,gender;
    int phn;
    
    void setInformation(String n,String g,int ph){
        name=n;
        gender=g;
        phn=ph;
    
    }
   
  void displayInformation(){
  
  
         System.out.println("Name : "+name);

         System.out.println("Name : "+gender);

         System.out.println("Name : "+phn);
         
         System.out.println("\n");
         
  }   
}

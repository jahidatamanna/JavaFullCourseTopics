
package oop;


public class MathClass {
    public static void main(String[] args) {
        
        System.out.println(Math.abs(-5));
        System.out.println(Math.sqrt(16));
        System.out.println(Math.pow(3,4));
        System.out.println(Math.PI);
        System.out.println(Math.log(2.0));
        System.out.println(Math.exp(1.0));
        System.out.println(Math.ceil(4.5));
        System.out.println(Math.floor(7.8));
        System.out.println(Math.min(-9.6, 8.9));
        System.out.println(Math.max(-9.6, 8.9));
        
        
        
        
        
    }
    
}

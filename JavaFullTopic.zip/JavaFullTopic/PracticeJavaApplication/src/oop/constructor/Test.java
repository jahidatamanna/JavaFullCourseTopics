
package oop.constructor;
public class Test {
   
    public static void main(String[] args) {
        
//        Teacher teacher1; //object declare
//        teacher1=new Teacher();//create object
Teacher teacher1=new Teacher("tamanna","female",12343234);
teacher1.displayInformation();

Teacher teacher2=new Teacher("jahida", "female", 97654323);
teacher2.displayInformation();


Teacher teacher3=new Teacher();


    }
    
}
 
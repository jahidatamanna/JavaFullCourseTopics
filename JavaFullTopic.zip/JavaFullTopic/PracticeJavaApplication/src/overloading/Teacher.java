
package overloading;


public class Teacher {
    
    String name,gender;
    int phone;
    
    
    Teacher(){
    
        System.out.println("no value");
    }
    
    Teacher(String n){
    name=n;
    
    }
    
    Teacher(String n,String g ,int ph){
    
    name=n;
    gender=g;
    phone=ph;
    
    }
    
   
    
    
    
      void displayInformation(){
  
  
         System.out.println("Name : "+name);

         System.out.println("Name : "+gender);

         System.out.println("Name : "+phone);
         
         System.out.println("\n");


      
  
  }
    
    
}


package overloading;


public class Test {
    public static void main(String[] args) {
        
        
         Teacher teacher1=new Teacher();
         teacher1.displayInformation();
        
          
         Teacher teacher2=new Teacher("tamanna");
         teacher2.displayInformation();
         
         
            
         Teacher teacher3=new Teacher("jahida","female",76543);
         teacher3.displayInformation();
        
    }
    
    
   
    
    
    
}

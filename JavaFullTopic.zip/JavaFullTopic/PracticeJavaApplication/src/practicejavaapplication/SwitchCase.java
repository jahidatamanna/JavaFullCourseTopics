
package practicejavaapplication;

import java.util.Scanner;


public class SwitchCase {
    public static void main(String[] args) {
       
        
    Scanner input=new Scanner(System.in);
    int language;
    System.out.print("Enter any Digit from 1 to 5 : ");
    language=input.nextInt();
    
    switch (language){
        
        
         case 0:
            System.out.println("this language is Bangali");
            break;
          case 1:
            System.out.println("this language is hindi");
            break;
           case 2:
            System.out.println("this language is pakistani");
            break;
            case 3:
            System.out.println("this language is urdu");
            break;
            case 4:
            System.out.println("this language is arabi");
            break;
            default:
                System.out.println("the language is not here");
        
    
    
    }
    
    
    
        
    }
    
}

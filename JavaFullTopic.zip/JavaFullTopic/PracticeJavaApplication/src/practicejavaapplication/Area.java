
package practicejavaapplication;

import java.util.Scanner;


public class Area {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
        int b,h;
        int area;
        
        System.out.print("enter the value of Base  : ");
        b=input.nextInt();
        
        System.out.print("enter the value of Height  : ");
        h=input.nextInt();
        
        area= (int) (0.5 * b * h) ;
          System.out.println("Area of Triangle is   : "+area);
 
        
        
        
    }
    
}


package practicejavaapplication;

import java.util.Scanner;


public class VowelConsonent {
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        
        char result;
        System.out.print("Do You Love JAVA ? : ");
        
        result=input.next().charAt(0);
        
        if(result=='Y' || result=='y'){
            
                   System.out.println("You are a java  lover ");
 
        }
        
        else if(result=='N' || result=='n'){
    
            System.out.println("You are not java lover ");

    }
        
        else{
            
                      System.out.println(" there is no comments ");
  
        }
        
        }
        
    
} 
        
        
     
        
        
//        char letter;
//        System.out.print("Enter any letter from A to Z : ");
//        letter=input.next().charAt(0);
//        
//        
//        if(letter>='a' && letter<='z'){
//        
//            System.out.println("The letter is small letter : " +letter);
//        
//        }
//        
//        else if(letter>='A' && letter<='Z')
//        {
//                        System.out.println("The letter is capital letter : " +letter);
//
//        }
//        
//        else{
//                        System.out.println("This is not a letter : "+letter);
//
//        }
        
        
        
        
        
//        if(letter=='a' || letter=='e' || letter=='i' || letter=='o' || letter=='u'){
//            System.out.print("the letter s Vowel : "+letter);
//        }
//        else{
//            System.out.println("The letter is consonant : "+letter);
//        }
//        
//                    System.out.println();

//        
//    }
//    
//}



package practicejavaapplication;


public class NewClass {
    public static void main(String[] args){
     
      int [] a={10,20,30,40};
      int l=0;
      int n=4;
      int r=n-1;
       int item=30;
        int mid;
     
while(l<r)
{
      mid=(r+1)/2;
      
      if(a[mid]==item)
      {
          System.out.println("item is found index : " +mid);
      }
      else if(a[mid]<item)
      {
          l=mid+1;
      
        }
      else{
          r=mid-1;
       }
      
      
System.out.println("item is not found index  ");
}
    
    }}

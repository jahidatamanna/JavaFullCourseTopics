
package practicejavaapplication;

import java.util.Scanner;


public class SeriesNumber {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n;
        int sum=0 ;
        System.out.print("Enter the value of N : ");
        n=input.nextInt();
        
        for(int i=1 ;i<=n;i=i+1){
            sum=sum+i*i;
            System.out.print(i+ "X" +i + " ");
        
        }
        System.out.println(" ");
        System.out.println("Sum of total value is : " +sum);
    }
    
    
    
}


package practicejavaapplication;




public class Continue {
    public static void main(String[] args) {
       
        
        for(int i=0;i<12;i++){
        
            if(i==10)
            {
            
             continue;
            
            }
            
            if(i==7)
            {
            
             continue;
            
            }
            if(i==5)
            {
            
             continue;
            
            }
            
            System.out.println(i);
            System.out.println("tamanna");
            System.out.println("01747115954");
            System.out.println("CSE");
            
        }
    }
    
}


package practicejavaapplication;

import java.util.Arrays;


public class ArraySorting {
    
    public static void main(String[] args) {
        
        int [] number={-4,-9,3,8,10};
        
        Arrays.sort(number);
        
        System.out.println("Assending : ");
        
        for (int i = 0; i < 5; i++) {
            System.out.println(" "+number[i]);
            
            
        }
        
          System.out.println("Dessending : ");
        
        for (int i = 4; i >= 0; i--) {
            System.out.println(" "+number[i]);
            
            
        }
                
        
        
        String[] name={"Ismaile","Tamanna","zafrin","Habiba"};
        
        Arrays.sort(name);
        
        System.out.println("Assending : ");
        
        for (int i = 0; i < 4; i++) {
            
            System.out.println(" "+name[i]);
            
        }
        
        System.out.println("");
        
        System.out.println("Dessending : ");
        
        for (int i = 3; i >= 0; i--) {
            
            System.out.println(" "+name[i]);
            
        }
        
        
        
        
    }
    
    
    
    
   
    
}
















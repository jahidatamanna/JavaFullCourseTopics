
package practicejavaapplication;

import java.util.Scanner;


public class AssignmentOperator {
    
    public static void main(String[] args){
        
        Scanner input =new Scanner(System.in);
        
        int a,b;
         
        System.out.print("value of a =  ");
        a=input.nextInt();
        
        System.out.print("value of b =  ");
        b=input.nextInt();
        
        
        a+=b;
        System.out.println("add : "+a);
        a-=b;
        System.out.println("sub : "+a);
         a*=b;
        System.out.println("mul : "+a);
         a/=b;
        System.out.println("div : "+a);
         a%=b;
        System.out.println("mod : "+a);

        
    }
    
    
}

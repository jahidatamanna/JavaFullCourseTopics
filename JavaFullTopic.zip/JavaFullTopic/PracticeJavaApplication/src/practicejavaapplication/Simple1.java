
package practicejavaapplication;

public class Simple1 {
    public static void main(String []args)
    {
      int id=101;
      char phn ='i';
    
    double price=124000;
    
        
    System.out.println("my id is : "+id);   
    System.out.println("my phone prise is : "+price);   
       
    }
   
    
    
    
    
    
}

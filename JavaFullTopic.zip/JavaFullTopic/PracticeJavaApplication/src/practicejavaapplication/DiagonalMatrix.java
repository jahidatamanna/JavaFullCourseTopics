
package practicejavaapplication;

import java.util.Scanner;


public class DiagonalMatrix {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int A[][]=new int[2][3];
        int sumOfDiagonal=0;
        int sumOfUpper=0;
        int sumOfLower=0;
        // input
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
                A[row][col]=input.nextInt();
               
            }
        }
         
             // uper ,diagonal, lower
             
              for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
             
             if(row==col){
            
            sumOfDiagonal=sumOfDiagonal+A[row][col];
            
        }
            
              if(row<col){
            
            sumOfUpper=sumOfUpper+A[row][col];
            
        }
              
                if(row>col){
            
            sumOfLower=sumOfLower+A[row][col];
            
        }
                
            }}
        
         System.out.println("sum of diagonal elements :"+sumOfDiagonal);    
        System.out.println("sum of upper triangle elements"+sumOfUpper); 
        System.out.println("sum of lower trianglr elements"+sumOfLower);
    }
    
}


package practicejavaapplication;
import java.util.Scanner;
public class SumOfOddNumberMtoN {
    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);
        int m,n,sum=0;
        System.out.print("enter the value of M : ");
        m=input.nextInt();
        System.out.print("enter the value of N : ");
        n=input.nextInt();
        
        
        for(int i=m;i<=n;i++)
        {
         if(i%2!=0){
            sum=sum+i;
            }
         

        }
        
        System.out.println("sum of all odd number from M to N is : " +sum);
        
        
    }}
        
        
        
        
        
        
        
        
        
//        for(int i=m;i<=n;i++)
//             {
//        if(i%2!=0)
//        {
//           sum=sum+i;
//        }
//             }
//               System.out.println("sum of all odd number : " +sum); 

             


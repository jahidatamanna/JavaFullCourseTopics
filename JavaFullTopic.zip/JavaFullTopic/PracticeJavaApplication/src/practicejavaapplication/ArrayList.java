//
//package practicejavaapplication;
//
////import java.util.ArrayList;
//import java.util.ArrayList;
//
//public class ArrayList {
//   
//    
//    public static void main(String[] args) {
//        
//        ArrayList<Integer> number= new ArrayList<Integer>();
//        System.out.println("size : "+number.size());
//        
//        //adding elements
//        
//        number.add(10); 
//        number.add(20);
//        number.add(30);
//        number.add(40);
//        number.add(3,500);
//        
//        
//        // simple way print
//       
//        System.out.println("Elements : "+number);
//        
//         //for each loop way print
////        for(int x:number){
////            System.out.print(" " +x);
////        }
//        
//      
//        
//        
//        
//                System.out.println(" size : "+number.size());
//                
//                
//                number.remove(2);
//                System.out.println("After removing : " +number);
//                System.out.println(" size after removing :" +number.size());
//
//        number.removeAll(number);
//        System.out.println(" after remove all "+number);
//        number.clear();
//                System.out.println(" leear all "+number);
//                 
//                boolean check = number.isEmpty();
//                System.out.println("boolean result : "+check);
//                
//                boolean contain=number.contains(30);
//                System.out.println(" is 30 is here : "+contain);
//
//        
//    }
//    
//    
//}

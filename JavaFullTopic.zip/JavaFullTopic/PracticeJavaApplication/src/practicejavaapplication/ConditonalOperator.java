
package practicejavaapplication;

import java.util.Scanner;


public class ConditonalOperator {
    
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        int num1,num2,large;
        System.out.println("Enter two number : ");
        num1=input.nextInt();
        num2=input.nextByte();
        
        large=(num1>num2)? num1:num2;
        System.out.println("large number : "+large);
        
    }
    
}

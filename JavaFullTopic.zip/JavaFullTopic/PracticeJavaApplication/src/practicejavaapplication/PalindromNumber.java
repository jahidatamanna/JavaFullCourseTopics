
package practicejavaapplication;

import java.util.Scanner;


public class PalindromNumber {
    public static void main(String[] args) {
       Scanner input=new Scanner(System.in);
       
       int num,sum=0,temp,r;
       System.out.print("enter any number : ");
       num=input.nextInt();
      temp=num;
      
      while(temp!=0){
        r=temp%10;
      sum=sum*10+r;
      temp=temp/10;
      
      }
    if(num==sum){
        System.out.println("this is palimdrom number : "+sum);
        
    } 
    else{
        System.out.println("this is not palindrom number "+sum);
    }
       
       
       
    }
    
}


package practicejavaapplication;

import java.util.Scanner;


public class Tempature {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
        int C,F;
        System.out.print("Enther the value of C : ");
        C=input.nextInt();
        
        F=(9/5)*C+32;
       System.out.println(" The value of F : "+F);

        
    }
    
}

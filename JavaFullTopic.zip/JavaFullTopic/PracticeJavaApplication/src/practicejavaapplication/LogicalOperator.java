
package practicejavaapplication;


public class LogicalOperator {
    
    public static void main(String[] args) {
        
        
    }
    
}

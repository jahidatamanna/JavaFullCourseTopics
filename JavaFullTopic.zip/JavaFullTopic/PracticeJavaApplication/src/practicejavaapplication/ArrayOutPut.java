
package practicejavaapplication;


public class ArrayOutPut {
    
    public static void main(String[] args) {
        int[][] number=new int[3][4];
        int k=0;
        
        for (int row = 0; row <3; row++) {
            for (int col = 0; col <4; col++) {
                number[row][col]=k;
                k++;
                
            }
            
        }
        //print elements
        
        for (int row = 0; row <3; row++) {
            for (int col = 0; col < 4; col++) {
                
                System.out.print(" "+number[row][col]);   
                
            }
            System.out.println("");
            
        }
        
        
    }
    
}

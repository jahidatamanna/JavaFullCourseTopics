
package practicejavaapplication;

import java.util.Scanner;

public class MtoNprimeNumber {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int m,n ;
        int count = 0;
        int TotalNumberOfPrime=0;
        System.out.print("enter starting value  m : ");
        m=input.nextInt();
        
        System.out.print("enter starting value  n : ");
        n=input.nextInt();
        //int totalPrimeNumber=0;
        
        for(int i=m;i<=n;i++){
        
           for(int j=2;j<=i-1;j++){
               
            if(i%j==0)
            {
            count++;
            break;
            }   
        }
            if(count==0 && i>2){
               System.out.println(i);
               TotalNumberOfPrime++;
                }
            
            count=0;
            
            
           }
        
        System.out.println("total prime number : "+TotalNumberOfPrime);
        
        
    }
}
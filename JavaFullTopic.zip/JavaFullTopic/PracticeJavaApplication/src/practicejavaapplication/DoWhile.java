
package practicejavaapplication;


public class DoWhile {
    public static void main(String[] args) {
        
        int i=11;
        do{
        System.out.println(i);
        i=i+2;
        }while(i<=10);
        
        
    }
    
}

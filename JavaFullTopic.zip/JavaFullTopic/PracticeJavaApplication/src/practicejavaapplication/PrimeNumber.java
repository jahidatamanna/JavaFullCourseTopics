
package practicejavaapplication;

import java.util.Scanner;


public class PrimeNumber {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int n ;
        System.out.print("enter positive number : ");
        n=input.nextByte();
        int count=0;
        
        if(n==0 || n==1){
        System.out.println("not prime number "+n);
        }
        else{
        
            for(int i=2;i<n;i++){
            if(n%i==0){
            count++;
            break;
            }
        
        }
             if(count==0){
            System.out.println("this number is  a prime number " +n);
        }
        else{
            System.out.println("this number is not a prime number "+n);
        }
        }
        
        
        
       
        
    }
    
}

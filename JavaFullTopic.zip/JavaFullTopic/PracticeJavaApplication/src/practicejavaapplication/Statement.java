
package practicejavaapplication;

import java.util.Scanner;


public class Statement {
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        
        char ch;
        
         System.out.print("Enter any letter : ");

        
        ch=input.next().charAt(0);
        
        if(ch=='a'){
        
            System.out.print("the letter is vowel : "+ch);
        
        }
        
        else if(ch=='e'){
        
            System.out.print("the letter is vowel : "+ch);
        
        }
         
        else if(ch=='i'){
        
            System.out.print("the letter is vowel : "+ch);
        
        }
        else if(ch=='o'){
        
            System.out.print("the letter is vowel : "+ch);
        
        }
         else if(ch=='u'){
        
            System.out.print("the letter is vowel : "+ch);
        
        }
        
         else{
        
            System.out.print("the letter is consonent : "+ch);
        
        }
             
        
        
//        Scanner input=new Scanner(System.in);
//        int num;
//        System.out.print("enter any posiive number:  ");
//        num=input.nextInt();
//        
//        if(num%2==0){
//            System.out.println("the number is even : "+num);
//        
//    }
//       
//        
//        else{
//                        System.out.println("the number is odd: "+num);
//
//        }
    
}
}

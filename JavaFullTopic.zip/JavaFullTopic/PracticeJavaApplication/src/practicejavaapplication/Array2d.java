
package practicejavaapplication;

import java.util.Scanner;


public class Array2d {
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
        
       int  number[]=new int[5];
      // int sum=0;
       System.out.print("enter 5 numbers : ");
       
                 number[0]=6;   

                number[1]=5;   

                number[2]=4;
                number[3]=3;
                number[4]=2;

        
        for (int i = 0; i < 5; i++) {
          
 System.out.println(number[i]);
        }
       
//        for (int i = 0; i < 5; i++) {
//            sum= sum + number[i];
//            
//        }
           //sum=number[0]+number[1]+number[2]+number[3]+number[4];
          
          // System.out.println("sum of arrays value : "+sum);
           //System.out.println(number[i]);
         
    }
    
    
}

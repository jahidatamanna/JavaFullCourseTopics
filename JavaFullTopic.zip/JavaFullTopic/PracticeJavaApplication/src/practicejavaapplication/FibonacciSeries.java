
package practicejavaapplication;

import java.util.Scanner;


public class FibonacciSeries {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
       
        int n,fibo ;
        
         System.out.print(" which fiboacci you want  to see  : ");
        n=input.nextInt();
//         System.out.print("Enter x : ");
//        x=input.nextInt();
        int first=0;
        int second=1;
        System.out.print(first+ " " +second);
        
        for(int i=3;i<=n;i++){
        
        fibo=first+second;
        System.out.print(" " + fibo);

            first=second;
            second=fibo;
            
        
        }

        System.out.println(" ");
        
        
    }
    
}

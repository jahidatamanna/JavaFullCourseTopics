
package practicejavaapplication;

import java.util.Scanner;


public class ValidationOfUserNamePass {
    public static void main(String[] args) {
   Scanner input = new Scanner(System.in);
   
//   
//   
           String a = "tamu";
           String b = "123";
           
            String s1, s2;
           
            System.out.println("enter name");
            s1 = input.nextLine();
            
             System.out.println("enter pass :");
            s2 = input.nextLine();
           
            while(true) {
                
                if(a.equals(s1) && b.equals(s2)) {
                    System.out.println("You are welcome");
                   break;
                }
                else{
                    System.out.println("Please try again");
                    s1 = input.nextLine();
                    s2 = input.nextLine();
                }
                
                 }
            
            
    }}        
        
        
        
        
        
        
        
  //  }}
        
        
        
        
        
        
        
        
        
        
//        Scanner input = new Scanner(System.in);
//        
//        
//        int spass ;
//        String  sname;
//        
//        System.out.print("enter yout name : ");
//        sname=input.next();
//        
//        System.out.print("enter yout pass : ");
//        spass=input.nextInt();
//        
//        if( sname=="tamanna" && spass==123){
//            System.out.println("welcom ");
//           
//        }
//        else{
//            System.out.println("sorry your enter password is wormg ");
//        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//        for (int i = 0; i < 10; i++) {
//            System.out.println("username : ");
//            String name=input.next();
//            
//            System.out.println("password : ");
//            int pass=input.nextInt();
//            
//            
//            
//               if(pass==123456 && name="tamu"){
//        
//            System.out.println("welcome to our community ");
//            break;
//        }
//        
//        else{
//        
//            System.out.println("sorry yor enterpasword is wrong ");
//        }
//            
//            
//        }
//        
//     
//        
        
        
        
        
        
        
        
        
        
        
        
        
        
//        
//    }
//    
//}

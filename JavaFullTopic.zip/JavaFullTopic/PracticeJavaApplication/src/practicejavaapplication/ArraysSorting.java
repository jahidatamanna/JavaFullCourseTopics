
package practicejavaapplication;

import java.util.Arrays;


public class ArraysSorting {
    public static void main(String[] args) {
        
        int []number={12,3,9,16,-1,-8};
         Arrays.sort(number, 0, 0);
        
         System.out.print("Ascending : ");
        for (int i = 0; i < 6; i++) {
            System.out.print(" " +number[i]);
            
        }
        System.out.println("");
                 System.out.print("descending : ");

        for (int i = 4; i>=0; i--) {
            System.out.print(" " +number[i]);
            
        }
        System.out.println("");
    
    //string[] names={"tamanna","jahida","inti"};
    String[] names={"tamanna","jahida","inti"};  
           Arrays.sort(names);
        for (int j = 0; j < 3; j++) {
            System.out.print(" " +names[j]);
            
        }
    
   
    
        System.out.println("");
    
    
    }
    
}

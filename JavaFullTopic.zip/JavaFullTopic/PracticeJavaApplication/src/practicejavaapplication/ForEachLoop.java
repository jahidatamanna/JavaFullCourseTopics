
package practicejavaapplication;


public class ForEachLoop {
    public static void main(String[] args) {
        
        int num[]={1,2,3,4,5};
        
       int sum=0;
        
      for(int x : num){
          sum=sum+x;
          System.out.println(x);
      }
                System.out.println("the sume is : " +sum);

        
        
    }
    
}

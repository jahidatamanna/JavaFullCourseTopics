
package practicejavaapplication;

import java.util.Scanner;


public class ReverseNumber {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num,r,temp;
        System.out.print("Enter number : ");
        num=input.nextInt();
        int sum=0;
        temp = num;
        
        while(temp!=0){
        r=temp%10;
        sum=sum*10+r;
        temp=temp/10;
        }
        
        System.out.println("Reverse number  "+sum);
        
    }
    
}

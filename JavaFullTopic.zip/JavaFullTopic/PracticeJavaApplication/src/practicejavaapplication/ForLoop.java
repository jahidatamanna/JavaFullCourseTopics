
package practicejavaapplication;

import java.util.Scanner;


public class ForLoop {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
//        
        int s,a,c ;
        
        System.out.print("enter strt value for loop : ");
        s=input.nextInt();
        
         System.out.print("increment by : ");
         a=input.nextInt();
         
        System.out.print("enter condition value for loop : ");
         c=input.nextInt();
         
      
       
        
        for(int i=0;i<c; i=i+a)
        {
        
        System.out.println(i+ " this is for loop "); 
        
        }
        
        
        
    }
    
}

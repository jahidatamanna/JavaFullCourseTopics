
package practicejavaapplication;


public class SomeOfLoop {
    
    public static void main(String[] args) {
      int i,sum;
      sum=0;
    for( i=1;i<=5;i++)
        
    {
   sum=i+sum;
  
  System.out.println(sum);

}
    
    }   
}


package practicejavaapplication;

import java.util.Scanner;


public class MtoNarmStrongNumber {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int m,n,sum=0,temp,r, totalArmStrongNumber=0;
        System.out.print("enter starting value from M : ");
        m=input.nextInt();
        System.out.print("enter ending value from N  : ");
        n=input.nextInt();
        for (int i = m; i <=n; i++) {
           temp=i;
           while(temp!=0){
            r=temp%10;
           sum=sum*10+r*r*r;
           temp=temp/10;
           }
            if(sum==i){
                System.out.println(" armStrong number : "+i);
               totalArmStrongNumber++;
            }
            else{
                  sum=0;
                  r=0;
            //System.out.println("not palindrom : "+i);
            }
           }
            System.out.println("total armStrong Number : "+ totalArmStrongNumber);   

        }
    
    
}


package practicejavaapplication;

import java.util.Scanner;

public class AND_Operator {
    
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        char ch1,ch2;
        System.out.print("Have you completed you masters ?  :");
        ch1=input.next().charAt(0);
        
        System.out.print("Are you fluent in English ? : ");
        ch2=input.next().charAt(0);
        
        if(ch1=='y' && ch2=='y'){
        System.out.println("You are eligiable for interview ");
        
        }
        else if (ch1=='n' && ch2=='n' ){
                    System.out.println("sorry Yyou are not eligiable for interview ");

        }
        
        else{
        System.out.println("You are not qualified");
        }
        
//        else if(ch1=='n' || ch2=='y'){
//            
//                                System.out.println("sorry Yyou are not qualified ");
//
//        
//        }
        
//        else if (ch1=='y' || ch2=='n'){
//            
//                                System.out.println("sorry Yyou are not qualified ");
//
//        
//        }
        
        
        
        
        
    }
    
}

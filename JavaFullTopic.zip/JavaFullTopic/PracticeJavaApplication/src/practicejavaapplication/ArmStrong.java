
package practicejavaapplication;

import java.util.Scanner;


public class ArmStrong {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int num,r,temp,sum=0;
        System.out.print("enter any number : ");
        num=input.nextInt();
        temp=num;
        
        while(temp!=0){
        
        r=temp%10;
        sum=sum+r*r*r;
        temp=temp/10;
        
        
        
        }
        
        if(num==sum){
            System.out.println("this is armstrong number : " +sum);
        }
        else{
            System.out.println("this is not a armstrong number " +sum);
        }
      
        
    }
    
}

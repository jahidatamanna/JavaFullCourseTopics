
package practicejavaapplication;

//import java.util.Scanner;


public class TwoDArray {
    public static void main(String[] args) {
       // Scanner input = new Scanner(System.in);
       
       int[][] num=new int[2][2];
       
       num[0][0]=3;
       num[0][1]=4;
       num[1][0]=5;
       num[1][1]=6;
       
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                
                
                        System.out.print(" "+num[row][col]);

                
            }
            System.out.println("");  
        }
       
//        System.out.println(" "+num[0][0]);
//
//        System.out.println(" "+num[0][1]);
//
//        System.out.println(" "+num[1][0]);
//
//        System.out.println(" "+num[1][1]);
        
        
        
    }
    
}

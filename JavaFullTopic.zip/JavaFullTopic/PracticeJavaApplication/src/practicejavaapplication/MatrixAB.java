
package practicejavaapplication;

import java.util.Scanner;


public class MatrixAB {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int [][]A=new int[3][3];
              
        int [][]B=new int[3][3];
       
        //getting input for A matrix 
            System.out.println("Enter A Matrix : ");
          for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                System.out.printf(" A[%d][%d] = ",row,col);
                A[row][col]=input.nextInt();
           }
       }
         
              System.out.println("Enter B Matrix : ");
             //getting input for B matrix 
            for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
             System.out.printf(" B[%d][%d] = ",row,col);
             B[row][col]=input.nextInt();
           }
       }
              //print A matrix
            System.out.print("Print  A : ");
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 2; col++) {
                 System.out.print("\t"+A[row][col]);
  
                }
                System.out.println("");
            
        }
            
            
            //print B matrix
            System.out.print("Print  B : ");
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 2; col++) {
                 System.out.print("\t"+B[row][col]);
  
                }
                System.out.println("");
            
        }
            
            
            
        
        }
    
}

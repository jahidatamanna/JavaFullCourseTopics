
package practicejavaapplication;

import java.util.Scanner;


public class InpurFromUser {
    
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        
        
  //Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
//System.out.print("Enter first number- ");  
//int a= sc.nextInt(); 
//
//System.out.print("Enter second number- ");  
//int b= sc.nextInt(); 
//
//System.out.print("Enter third number- ");  
//int c= sc.nextInt();
//
//int d=a+b+c;  
//System.out.println("Total= " +d);
        
         
      
        System.out.print("Enter your name : ");
        String Name = input.nextLine();
//       
        System.out.print("Enter your phone price : ");
          double price=input.nextInt();

        System.out.println("My name is : "+Name);
        System.out.println("My  phone price is : "+price);

       

        
        
   
    

     
        
    }
    
}

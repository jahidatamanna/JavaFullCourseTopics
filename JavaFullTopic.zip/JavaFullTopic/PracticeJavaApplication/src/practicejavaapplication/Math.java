
//package practicejavaapplication;
//
//import java.util.Scanner;


//public class Math {
//    public static void main(String[] args) {
//        
//        Scanner input=new Scanner(System.in);
//        int a,b;
//       System.out.print("enter the value of A : = ");
//        a=input.nextInt();
//        System.out.print("enter the value of  : = ");
//        b=input.nextInt();
        

//        int max=Math.max(a,b);
//        System.out.println(max);
        
      
        
//        
//    }
//    
//}

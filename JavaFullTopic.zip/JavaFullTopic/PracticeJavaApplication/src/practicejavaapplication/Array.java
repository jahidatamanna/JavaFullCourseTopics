
package practicejavaapplication;

import java.util.Scanner;

public class Array {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sum=0;
       int[]a=new int[5];
        System.out.print("enter value : ");
       for(int i=0;i<5;i++){
            a[i]=input.nextInt();
        }
       for(int i =0;i<5;i++){
        sum=sum+a[i];
        }
       System.out.println("the sum is : "+sum);
       int avg=sum/5;
       System.out.println("the average is : "+avg);
        
     int max=a[0];
        for (int i = 0; i <5; i++) {
            if (max<a[i]) {
                max=a[i];
           }
      }
        System.out.println("max is "+max);

        int min=a[0];
         for (int i = 0; i <5; i++) {
            if (min>a[i]) {
                min=a[i];
           }
        }
       System.out.println("min is "+min);
  }
    
        
  
  
  
    
  
      
    
           
           
    }
    


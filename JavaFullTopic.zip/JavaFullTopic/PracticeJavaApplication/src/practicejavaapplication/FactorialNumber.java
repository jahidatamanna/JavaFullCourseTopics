
package practicejavaapplication;

import java.util.Scanner;


public class FactorialNumber {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int i,fact,number;
       
        System.out.print("enther the value of i : ");
        i=input.nextInt();
        
         System.out.print("enther the value of fact : ");
        fact=input.nextInt();
        
         System.out.print("enther the value of number : ");
        number=input.nextInt();
        
         for(i=fact;i<=number;i++){    
         fact=fact*i;    
           }
          System.out.println("Factorial of "+number+" is: "+fact);    

         
        
        
    }
    
}




 
  


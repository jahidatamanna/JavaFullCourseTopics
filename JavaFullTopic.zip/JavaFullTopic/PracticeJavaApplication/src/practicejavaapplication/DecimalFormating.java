
package practicejavaapplication;
import java.text.DecimalFormat;



public class DecimalFormating {
    
    public static void main(String[] args) {
      DecimalFormating ob =new DecimalFormating();//(0.000) = . er por 3 ghor dekhabe
        double x =1.2345;
        System.out.println(" X ");//+ob.format(x) hobe
    }
    
}

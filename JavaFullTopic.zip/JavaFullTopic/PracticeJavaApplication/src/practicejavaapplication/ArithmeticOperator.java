
package practicejavaapplication;

import java.util.Scanner;



public class ArithmeticOperator {
    public static void main(String[] args){
       
      Scanner input=new Scanner(System.in);
      
      int num1,num2,result;
      
      System.out.print("Enter the first value : ");
      num1=input.nextInt();
      
       System.out.print("Enter the seond value : ");
      num2=input.nextInt();
      
      result=num1+num2;
             System.out.println("the result is : " +result);

      
      
        
        
        
    }
   
    
}

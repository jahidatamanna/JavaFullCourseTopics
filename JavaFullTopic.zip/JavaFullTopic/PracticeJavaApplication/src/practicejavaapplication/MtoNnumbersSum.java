
package practicejavaapplication;

import java.util.Scanner;


public class MtoNnumbersSum {
    
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
       int m,n;
        System.out.print("Enter the value of M : ");
        m=input.nextInt();
        
         System.out.print("Enter the value of N : ");
        n=input.nextInt();
         int sum=0;
       for(int i=m;i<=n;i++){
           
           if(i%2==0){
           sum=sum+i;
               System.out.println(" all even numbers : "+i);
           }
           
       

       }
      System.out.println("sum of all the even numbers from 1 to 100 number : "+sum);
        
    }
}


package practicejavaapplication;

import java.util.Scanner;


public class FactorialDemo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int number,fact=1;
        System.out.print("Enter any positive number : ");
        number=input.nextInt();
        for(int i=number;i>=1;i--)  {
            
            fact=fact*i;
        }
        
        
        System.out.println("factorial of " +number+ " is = " +fact);
            
        
    }
    
}

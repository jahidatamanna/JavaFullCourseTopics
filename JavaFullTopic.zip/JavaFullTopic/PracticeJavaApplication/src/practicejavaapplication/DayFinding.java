
package practicejavaapplication;

import java.util.Scanner;


public class DayFinding {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
         int x;
         System.out.print("enter a digit from 0 to 7 : ");
         x=input.nextInt();
         
        switch(x){
        
            case 0:
                System.out.println("Saturday");
            
                break;
            
            case 1:
                System.out.println(" Sunday");
                break;
            
             case 2:
                 System.out.println("Monday");
                break;
            
              case 3:
                  System.out.println(" Tuesday");
                break;
            
              
               case 4:
                   System.out.println(" Wednesday");
                break;
            
                case 5:
                    System.out.println("Thursay");
                break;
            
                 case 6:
                     System.out.println("Friday");
                break;
            
                
         
        
        }
         
         
         
         
    }
    
}

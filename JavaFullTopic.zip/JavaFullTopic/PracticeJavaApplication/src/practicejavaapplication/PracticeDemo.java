
package practicejavaapplication;
import java.util.Scanner;


public class PracticeDemo {
    
    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
 int sum=0;
        int[]a=new int[5];
        System.out.println("enter 5 number : ");
        for (int i = 0; i < 5; i++) {
            
            a[i]=input.nextInt();
            
        }
        
         for (int i = 0; i < 5; i++) {
            
        sum=sum+a[i];
            
        }
        
        
        
        System.out.println("the sum is : "+sum);
       
        
    }
    
}

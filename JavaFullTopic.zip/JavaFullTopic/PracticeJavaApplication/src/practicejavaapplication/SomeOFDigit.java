
package practicejavaapplication;

import java.util.Scanner;


public class SomeOFDigit {
    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);
    
    
    int n,r,temp;
    int sum=0;
            System.out.print("enter input : ");

    n=input.nextInt();
        temp=n;
        while(temp!=0){
        r=temp%10;
        sum=sum+r;
        temp=temp/10;
        
        
        
        }
        System.out.println(" sum of digit : " +sum);
    
    }
    
}

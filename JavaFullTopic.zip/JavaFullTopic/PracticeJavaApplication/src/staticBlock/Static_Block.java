
package staticBlock;


public class Static_Block {
  
    static int id;
    static String name;
    
    
    static{ //this is a static block
    id=123;
    name="tamu";
    
    }
    
    static void display(){
    
        System.out.println("id is :"+id);
        System.out.println("name is :"+name);
    
    }
    
    
    public static void main(String[] args) {
        Static_Block.display();
    }
    
    
}

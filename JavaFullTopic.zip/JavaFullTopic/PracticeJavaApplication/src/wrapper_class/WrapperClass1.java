
package wrapper_class;


public class WrapperClass1 {
    public static void main(String[] args) {
        // primitive to object
        int x=10;
        Integer y = Integer.valueOf(x);
        System.out.println(y);
        
        int p=20; //Autoboxing
        Integer q=p;
        System.out.println(q);
        
        //objejct to primitive :unboxing
        Double m=new Double(5.55);
        
        double n =m;
        System.out.println(n);
        
        
    }
    
}

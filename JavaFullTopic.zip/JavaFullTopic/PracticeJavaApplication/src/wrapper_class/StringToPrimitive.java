
package wrapper_class;


public class StringToPrimitive {
    public static void main(String[] args) {
        
        String s ="34";
        int i =Integer.parseInt(s);
        System.out.println(i);
        
        
        String D ="34";
        double d =Double.parseDouble(D);
        System.out.println(d);
        
        
    }
    
}

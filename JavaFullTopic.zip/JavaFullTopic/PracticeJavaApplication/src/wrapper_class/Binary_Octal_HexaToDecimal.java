
package wrapper_class;


public class Binary_Octal_HexaToDecimal {
    public static void main(String[] args) {
        
        String binary="101010";
        Integer decimal=Integer.parseInt(binary,2);
        System.out.println(decimal);
        
        
        String octal="101010";
        Integer decimal1=Integer.parseInt(octal,8);
        System.out.println(decimal1);
        
        
         String hexadecimal="101010";
        Integer decimal2=Integer.parseInt(hexadecimal,16);
        System.out.println(decimal2);
        
    }
    
}

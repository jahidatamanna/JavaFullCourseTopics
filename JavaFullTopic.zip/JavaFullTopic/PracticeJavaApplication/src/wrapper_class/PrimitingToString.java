
package wrapper_class;


public class PrimitingToString {
    public static void main(String[] args) {
           
        
        double d=12.99;
        String D = Double.toString(d);
        System.out.println(D);
        
        
    }
    
}

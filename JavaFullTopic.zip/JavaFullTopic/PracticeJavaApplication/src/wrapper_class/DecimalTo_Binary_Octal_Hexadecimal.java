
package wrapper_class;

import java.util.Scanner;


public class DecimalTo_Binary_Octal_Hexadecimal {
    
    public static void main(String[] args) {
        
      Scanner input = new Scanner(System.in);

        int decimal;
        System.out.print("enter any number : ");
        decimal=input.nextInt();

        
        String binary=Integer.toBinaryString(decimal);
        System.out.println(binary);
        
        String octal=Integer.toOctalString(decimal);
        System.out.println(octal);
        
         String hexa=Integer.toHexString(decimal);
        System.out.println(hexa);
        
    }
    
}

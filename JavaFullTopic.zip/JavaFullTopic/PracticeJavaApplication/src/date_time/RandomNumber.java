
package date_time;

import java.util.Random; 


public class RandomNumber {
    public static void main(String[] args) {
        Random rand=new Random();
        int randomNumber=rand.nextInt(91)+10; //10 to 100 any random number dekhabe
        System.out.println("random number : "+randomNumber);
        
    }
    
}

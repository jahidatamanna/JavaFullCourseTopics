
package final_keywordForMethod;


public class Student extends University {
    
    // display();
     void display2(){
    
        System.out.println("Student");
    
    
    }
    
}


package final_keywordForMethod;


public class University {
    
    final void display(){
    
        System.out.println("University");
    
    }
    
}


package LinkedListDemo;

import java.util.LinkedList;


public class StudentList {
    public static void main(String[] args) {
        
        //student linkedList
        LinkedList<Student> list=new  LinkedList<Student>();
        
        // create student
        Student s1 = new Student("x","Ten",12);
        Student s2 = new Student("Y","Ten",13);
        Student s3 = new Student("Z","Ten",14);
        Student s4 = new Student("Z","Ten",15);
        
        
        // adding value to the student
        list.add(s1);
        list.add(s2);
        list.add(s3);
        list.add(s4);
        
        
        
        for(Student s: list){
        
            System.out.println(s.name + "  " + s.className + " " + s.id+" ");
        
        }
    
        
    }
    
}
 
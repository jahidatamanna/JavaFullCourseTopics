
package LinkedListDemo;
import java.util.LinkedList;
public class LinkListdemo {
    
    public static void main(String[] args) {
        LinkedList<String> countryName = new LinkedList<String>();
        
        countryName.add("bangladesh");
        countryName.add("india");
        countryName.add("nepal");
        countryName.add("pakistan");
        countryName.add("saudi");
        countryName.add(3,"USA");
        countryName.addFirst("japan");
        countryName.addLast("Australia");
        countryName.remove("Australia");
        countryName.removeFirst();
        
        
         for(String country:countryName){
                  System.out.println(country);
                                          }  
        System.out.println(countryName.size());
        
                System.out.println("First Element : "+countryName.getFirst());
countryName.clear();
        System.out.println(countryName);
        
                                             } 
                                               }


        
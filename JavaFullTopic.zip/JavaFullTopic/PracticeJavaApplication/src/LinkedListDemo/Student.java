
package LinkedListDemo;


public class Student {
    
    String name,className;
    int id;
    
    Student(String name,String className,int id){
    
    this.name=name;
    this.id=id;
    this.className=className;
    }
    
}

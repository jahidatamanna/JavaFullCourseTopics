
package inheritance;
public class Person  {
     String name;
    int age;
    
    void displayInformation1(){
    
        System.out.println("Name :"+name);
        System.out.println("Age :"+age);
    
    
    } 
    
    
}

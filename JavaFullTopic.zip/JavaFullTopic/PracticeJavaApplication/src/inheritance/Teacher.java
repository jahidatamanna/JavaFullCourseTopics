
package inheritance;


public class Teacher extends Person {
    
    //  String name;
    // int age;
    
    String qualification;
    
    
    void displayInformation2(){
        
         displayInformation1();
        //System.out.println("Name"+name);
        //System.out.println("Age"+age);
        System.out.println("Qualification"+qualification);
        
    
    
    } 
    
    
    
    
    
}


package inheritance;


public class Test {
    public static void main(String[] args) {
        
       Teacher t1=new Teacher();
       t1.name="tamu";
       t1.age=24;
       t1.qualification=" BSC in CSE";
       t1.displayInformation2();
       
        
    }
    
}

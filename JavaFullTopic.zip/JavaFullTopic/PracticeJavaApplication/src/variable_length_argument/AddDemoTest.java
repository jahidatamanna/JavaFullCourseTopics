
package variable_length_argument;


public class AddDemoTest {
    public static void main(String[] args) {
     
        
        AddDemo obj=new AddDemo();
        obj.add(12,22);
        obj.add(12,22,222);
        obj.add(12,22,222,2222);
        
    }
    
}

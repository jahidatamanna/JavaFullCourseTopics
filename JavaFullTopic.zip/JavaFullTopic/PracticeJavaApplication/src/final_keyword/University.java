
package final_keyword;

public class University {
    
  final  String name="AIUB";
   final int fee; //blank variable
   static final int id ; //static blank final variable
   
   University (){
   
   fee=1234345;
   
   }
   
   static{
       
       id=124;
   
   
   
   }
    
    void display(){
    
        System.out.println("name : "+name);
        System.out.println("Fee : "+fee);
        System.out.println("ID : "+id);
    
    }
    
    
    
    
    
}

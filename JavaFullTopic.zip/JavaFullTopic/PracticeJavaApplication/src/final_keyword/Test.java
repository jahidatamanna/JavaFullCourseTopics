
package final_keyword;


public class Test {
    public static void main(String[] args) {
      
     
        
        University ob=new University ();
        ob.display();
        
        
    }
    
}


package superkeyword2;


public class Test {
    public static void main(String[] args) {
        
        Car BMW = new Car("white",350,5);
        BMW.attribute();
        
        
        
    }
    
}

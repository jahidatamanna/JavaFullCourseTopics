
package interfaceMultipleInheritance;

public interface A {
    void play();
    
}


package interfaceMultipleInheritance;


public class C implements A,B {
    
  public  void play(){
      
      System.out.println("hello i am from c ");
    
        
    
    }
    
    
    
    
}

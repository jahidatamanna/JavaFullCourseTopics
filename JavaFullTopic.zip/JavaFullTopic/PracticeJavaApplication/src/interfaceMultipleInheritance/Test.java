
package interfaceMultipleInheritance;


public class Test {
    public static void main(String[] args) {
        
        C ob=new C();
        ob.play();
        
    }
    
}

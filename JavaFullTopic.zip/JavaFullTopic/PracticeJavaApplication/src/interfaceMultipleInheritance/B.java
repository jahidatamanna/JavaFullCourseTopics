
package interfaceMultipleInheritance;


public interface B {
    
    void play();
    
}

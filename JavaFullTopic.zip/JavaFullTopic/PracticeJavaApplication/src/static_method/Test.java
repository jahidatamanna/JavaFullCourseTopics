
package static_method;

public class Test {
    public static void main(String[] args) {
     
        StaticMethod obj=new StaticMethod();
        obj.display1();
        
        StaticMethod.display2();
        
        
    }
    
}

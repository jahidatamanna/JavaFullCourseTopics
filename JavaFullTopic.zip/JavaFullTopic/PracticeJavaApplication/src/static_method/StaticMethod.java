
package static_method;


public class StaticMethod {
    
    void display1(){
    
        System.out.println("i am not a static method");
    }
    
    static void display2(){
    
        System.out.println("i am static method");
    }
    
}

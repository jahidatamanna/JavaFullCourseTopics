
package interfaceClass;


public class Cat implements Animal {
    
    
   public void eat(){
   
       System.out.println("Cat can eat Fish");
   } 
}

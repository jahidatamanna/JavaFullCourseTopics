
package interfaceClass;

public interface  Animal {
    public abstract void eat();
    
    
    
}

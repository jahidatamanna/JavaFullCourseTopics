
package interfaceClass;


public class Dog  implements Animal{
    
    public void eat(){
    
        System.out.println("dogs can eat egg");
    }
    
}

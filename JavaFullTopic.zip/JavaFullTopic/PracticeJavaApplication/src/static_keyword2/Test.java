
package static_keyword2;

public class Test {
    public static void main(String[] args) {
        
        Student s1=new Student();
        s1.totalCount();
        Student s2=new Student();
        s2.totalCount();
        Student s3=new Student();
        s3.totalCount();
        
    }
    
}

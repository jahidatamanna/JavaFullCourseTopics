
package static_keyword2;


public class Student {
    
    static int count;
    
    Student(){

  count++;
}
    
    void totalCount(){
    
        System.out.println("Total Count : "+count);
    }
    
    
    
    
    
}


package polymorphism2;


public class Triangle extends Shape {
    //area
    
    double base,height;
    
    Triangle(double base,double heigth){
    
    this.base=base;
    this.height=heigth;
    }
    
 
     @Override
     double area(){
         System.out.print("Area for Triangle : ");
         return 0.5*height*base ;
         
    }
    
}

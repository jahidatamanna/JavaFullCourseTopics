
package methodoverloading;


public class Test {
    public static void main(String[] args) {
       
      method_overloading obj1=new method_overloading();
      obj1.add(3,4);
      
       method_overloading obj2=new method_overloading();
      obj1.add(3.0,9.9);
      
      
       method_overloading obj=new method_overloading();
      obj1.add();
              
      
        
        
    }
    
}

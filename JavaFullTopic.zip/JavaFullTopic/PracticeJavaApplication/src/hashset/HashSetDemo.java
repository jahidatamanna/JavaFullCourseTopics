
package hashset;

import java.util.HashSet;


public class HashSetDemo {
    public static void main(String[] args) {
        
    
    
    HashSet<String> FruitsName=new HashSet<String>();
    
    FruitsName.add("apple");
    FruitsName.add("mango");
    FruitsName.add("bana");
    FruitsName.add("stroberry");
    
    
    System.out.print(FruitsName);
    
}}


package hash;

import java.util.HashMap;


public class HashMapDemo {
    
     public static void main(String[] args) {
        
        
      HashMap <Integer,String> customer=new HashMap <Integer,String>();
      //put =insert  nd get=print
      
      customer.put(101,"tamu" );
      customer.put(102,"p" );
      customer.put(103,"q" );
      
         System.out.println(customer.get(101));
      
      
      
        
    }
    
    
}

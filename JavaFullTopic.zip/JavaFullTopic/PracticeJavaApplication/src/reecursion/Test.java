
package reecursion;

public class Test {
    public static void main(String[] args) {
        
     FactorialUsingRecurion obj=new FactorialUsingRecurion();
     int result=obj.fact(5);
        System.out.println("the value of factorial 5 is : "+result);
        
         result=obj.fact(4);
        System.out.println("the value of factorial 5 is : "+result);
        
        
    }
    
}

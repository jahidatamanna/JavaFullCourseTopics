
package returningvalue;


public class Test {
    public static void main(String[] args) {
        
        
        ReturningValueDemo obj1=new ReturningValueDemo();
        System.out.println("square value of obj1: "+obj1.square(5));
        
        ReturningValueDemo obj2=new ReturningValueDemo();
        System.out.println("square value of obj2: "+obj2.square(6));
        
    }
    
}

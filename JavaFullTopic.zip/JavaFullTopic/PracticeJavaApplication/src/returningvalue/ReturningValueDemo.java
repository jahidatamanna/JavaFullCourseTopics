
package returningvalue;


public class ReturningValueDemo {
    
    int square(int value){
    return value*value;
    }
    
}

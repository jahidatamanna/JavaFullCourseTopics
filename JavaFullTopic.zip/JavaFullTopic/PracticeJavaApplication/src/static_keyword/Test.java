
package static_keyword;


public class Test {
    
    public static void main(String[] args) {
        System.out.println(""+student.uni);
        
        student s1=new student("tamanna",123);
        student s2=new student("jahida",234);
        
        s1.displayInformation();
        s2.displayInformation();
        
        
        
    }
    
    
    
}

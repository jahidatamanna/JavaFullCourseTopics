
package static_keyword;


public class student {
       
static String uni= "aiub";
 
    String name;
    int id;
    static String universityName = "AIUB";
    
    
    student(String n,int i){
        name=n;
        id=i;
    }
    
    void displayInformation(){
        System.out.println("name : "+name);
        System.out.println("ID : "+id);
        System.out.println("University  : "+universityName);
        System.out.println();
    
}
}


package abstractcls;


public class Tamanna extends MobileUsers {
    
    
        @Override
      void sendMassage(){

            System.out.println("i am tamanna");

}
    
}

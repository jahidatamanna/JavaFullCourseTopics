
package abstractcls;

public class Jahida extends MobileUsers {
    // call nd send method chole asche
      @Override
      void sendMassage(){

            System.out.println("i am jahida");

}
    
}

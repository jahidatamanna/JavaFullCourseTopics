
package abstractcls;


public abstract class MobileUsers {
    
  abstract  void sendMassage();
  
  void call(){ //non abstract
      System.out.println("Hlw i am call method");
  }
  
    
}

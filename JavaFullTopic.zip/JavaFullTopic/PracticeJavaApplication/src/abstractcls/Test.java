
package abstractcls;


public class Test {
    public static void main(String[] args) {
        
      MobileUsers mu;
      
      mu=new Jahida();
      mu.call();
      mu.sendMassage();
      
      mu=new Tamanna();
      mu.sendMassage();
      
        
        
    }
    
}


package string;


public class StringDemo2 {
    public static void main(String[] args) {
        String name="  bangladesh is      my ountry    ";
        System.out.println(" "+name);
        
        String SpaceRemove=name.trim();
        System.out.println(""+SpaceRemove);
        
        char ch = name.charAt(0); // 0 number index value
        System.out.println(" "+ch);
        
        int value=name.codePointAt(0); // 0 number indes valu er asci value
        System.out.println(""+value);
        
        int pos=name.indexOf("la");// la er index number
        System.out.println("first position of la: "+pos);
        
        int pos2=name.lastIndexOf("a");
        System.out.println("last position of a : "+pos2);
        
        
    }
    
}

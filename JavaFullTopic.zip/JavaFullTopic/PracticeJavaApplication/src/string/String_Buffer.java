
package string;


public class String_Buffer {
    public static void main(String[] args) {
        
//        String s1="tamanna";
//        StringBuffer s2 = new StringBuffer(s1);
//        System.out.println(s1);
//        
//        s2.append(" jahida ");
//        s2.append(25);
//        System.out.println(s2);


     String s1="tamanna";
     
     StringBuffer sb=new StringBuffer(s1);
     
     String s2 = sb.reverse().toString();
     
     if(s1.equals(sb)){
         System.out.println("palindrom");
     }
     else{
         System.out.println("not palindrom");
     }


    }
    
}

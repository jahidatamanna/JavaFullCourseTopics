
package string;


public class StringDemo3 {
    public static void main(String[] args) {
        
        String s1="bangladesh is my country";
        System.out.println(" "+s1);
        
        String s2=s1.replace('b','B');// b replace by B
        System.out.println(s2);
        
        
        String[] s3=s1.split(" ");
        for(String x:s3){
        
            System.out.println(x);
        }
        
    }
    
}

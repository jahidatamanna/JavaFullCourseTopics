
package string;


public class StringBuilder {
    public static void main(String[] args) {
       
//        StringBuilder str = new StringBuilder("tamanna");
//        str.append(" jahida");
//        
//        System.out.println(" str : "+str);
//         str.delete(2,5);
//         System.out.println(str);
        
    }
    
}


package string;


public class StringDemo1 {
    
    public static void main(String[] args) {
        
        String s1="Tamanna jaheda";
        String s2= new String("tamanna jaheda");
         char [] s3 = {'a','k','t'};
                 System.out.println(s3);

        System.out.println(" "+s1);
        System.out.println(" "+s2);
        
        int len=s1.length();
        System.out.println(" s1 length is : "+len);
        
        boolean con=s1.contains("jaheda");
        System.out.println(""+con);
        
       
        
        if(s1.equalsIgnoreCase(s2)){
            System.out.println("equals");
        
        }
        else {
            System.out.println("not equals");
        }
        
         boolean b =s1.isEmpty();
        System.out.println(b);
        
        String s4="inti";
        String s5="minti";
        String Fs=s4.concat(s5);
        System.out.println(Fs);
        
        String upperName=Fs.toUpperCase();
        System.out.println("upper case : "+upperName);
        
        boolean B = Fs.startsWith("i");
        System.out.println(" B : "+B);
        boolean Endswith = Fs.startsWith("ti");
        System.out.println("last with : "+Endswith);
        
        String[] name={"tams","tamu"};
//        for(String x:name){
//            System.out.println("names: "+x);
//        }
        
        for (int i = 0; i < 2; i++) {
            System.out.println("names:"+name[i]);
            
        }
        
        
    }
    
}

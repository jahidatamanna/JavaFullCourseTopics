
package polymorphism;

public class Teacher extends Person {
    
    
      @Override
      void display(){
    
        System.out.println("i am a Teacher");
    
    }
    
}

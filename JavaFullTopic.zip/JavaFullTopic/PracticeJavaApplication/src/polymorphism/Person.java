
package polymorphism;


public class Person {
    
    void display(){
    
        System.out.println("i am a person");
    
    }
    
    
}


package polymorphism;

public class Student extends Person {
      @Override
      void display(){
    
        System.out.println("i am a student");
    
    }
    
}

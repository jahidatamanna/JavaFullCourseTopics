
package exceptionHandling;


public class ExceptionDemo {
    public static void main(String[] args) {
        
       try{
       
        int x=10;
        int y=0;
        int result =x/y;
        System.out.println("result : "+result);
       
       }
       catch(StringIndexOutOfBoundsException e1){
       
           System.out.println("the result : "+e1);
       
       }
       
        catch(ArithmeticException e2){
       
           System.out.println("the result : "+e2);
       
       }
       
       finally{
           
       System.out.println("next line ");
       }
        
        
        
    }
    
}

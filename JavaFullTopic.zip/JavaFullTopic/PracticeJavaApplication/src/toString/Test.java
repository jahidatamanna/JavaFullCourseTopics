
package toString;


public class Test {
    public static void main(String[] args) {
        
        
        Person p1=new Person("Tamanna",24);
        Person p2=new Person("jaheda",25);
        
        System.out.println(p1);
        System.out.println(p2);
        
    }
    
}


package instanceOperetor;


public class Animal {
    
    
    
}

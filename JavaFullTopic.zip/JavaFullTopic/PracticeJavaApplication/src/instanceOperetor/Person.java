
package instanceOperetor;


public class Person extends Animal  {
    
}


package instanceOperetor;


public class Teacher  extends Person {
    
}

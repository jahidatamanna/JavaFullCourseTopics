
package methodOverriding;


public class Test {
    public static void main(String[] args) {
        
        Person p1=new Person();
        p1.name="tamanna";
        p1.age=24;
        p1.display();
        
        
         Teacher t1=new Teacher();
        t1.name="jahida";
        t1.age=25;
        t1.qualification="Bsc in CSE";
        t1.display();
        
        
    }
    
}

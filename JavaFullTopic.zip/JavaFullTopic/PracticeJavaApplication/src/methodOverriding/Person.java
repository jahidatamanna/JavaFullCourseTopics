
package methodOverriding;


public class Person {
    
    
    int age;
    String name;
    
    
    
    void display(){
    
        System.out.println("name : "+name);
        System.out.println("age : "+age);
    
    }
    
    
    
}

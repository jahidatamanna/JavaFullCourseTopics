
package methodOverriding;


public class Teacher extends Person {
    
    String qualification;
    
    @Override
    void display(){
    
         System.out.println("name : "+name);
        System.out.println("age : "+age);
        System.out.println("qualification : "+qualification);
    
    
    
    }
}
